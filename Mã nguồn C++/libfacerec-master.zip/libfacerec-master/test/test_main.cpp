
#include "opencv2/ts/ts.hpp"
#include "opencv2/ts/ts_gtest.h"

CV_TEST_MAIN("facerec")
