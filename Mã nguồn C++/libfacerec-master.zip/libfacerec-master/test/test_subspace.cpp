
#include "opencv2/core/core.hpp"
#include "opencv2/ts/ts.hpp"

// some helper methods for testing
#include "test_funs.hpp"
#include "helper.hpp"

using namespace cv;
using namespace std;


//------------------------------------------------------------------------------
// subspace::project
//------------------------------------------------------------------------------
TEST(TestSubspace, subspaceProject_EmptyMean) {
    // TODO
}

TEST(TestSubspace, subspaceProject_CorrectShapes) {
    // TODO
}

TEST(TestSubspace, subspaceProject_WrongShapes) {
    // TODO
}

TEST(TestSubspace, subspaceProject_DifferentTypes) {
    // TODO
}

//------------------------------------------------------------------------------
// subspace::reconstruct
//------------------------------------------------------------------------------

TEST(TestSubspace, subspaceReconstruct_EmptyMean) {
    // TODO
}

TEST(TestSubspace, subspaceReconstruct_CorrectShapes) {
    // TODO
}

TEST(TestSubspace, subspaceReconstruct_WrongShapes) {
    // TODO
}

TEST(TestSubspace, subspaceReconstruct_DifferentTypes) {
    // TODO
}
